from django.apps import AppConfig


class Worker1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'worker1'
